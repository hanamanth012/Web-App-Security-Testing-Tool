/**
 * Layout.jsx
 * Main layout wrapper with sidebar navigation
 * Used for all authenticated pages
 */

import { useState } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import {
  MdDashboard,
  MdSecurity,
  MdHistory,
  MdLogout,
  MdMenu,
  MdClose,
  MdShield,
  MdPerson
} from 'react-icons/md'
import { RiRadarLine } from 'react-icons/ri'

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  // Navigation items
  const navItems = [
    { to: '/dashboard', icon: MdDashboard, label: 'Dashboard' },
    { to: '/scanner', icon: RiRadarLine, label: 'Scanner' },
    { to: '/history', icon: MdHistory, label: 'Scan History' },
  ]

  return (
    <div className="min-h-screen bg-cyber-black flex grid-bg">
      {/* ===== SIDEBAR ===== */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-16'
        } bg-cyber-dark border-r border-cyber-border flex flex-col transition-all duration-300 relative z-10`}
      >
        {/* Logo area */}
        <div className="p-4 border-b border-cyber-border flex items-center gap-3">
          <MdShield className="text-neon-green text-2xl flex-shrink-0" />
          {sidebarOpen && (
            <span className="font-display text-neon-green font-bold text-lg neon-text tracking-widest">
              WEBSCAN<span className="text-white">X</span>
            </span>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded text-sm transition-all duration-200 font-mono
                ${isActive
                  ? 'nav-active'
                  : 'text-gray-500 hover:text-neon-green hover:bg-cyber-gray'
                }`
              }
            >
              <Icon className="text-xl flex-shrink-0" />
              {sidebarOpen && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User info + logout */}
        <div className="p-3 border-t border-cyber-border">
          {sidebarOpen && (
            <div className="flex items-center gap-3 px-3 py-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-cyber-gray border border-neon-green/30 flex items-center justify-center">
                <MdPerson className="text-neon-green text-sm" />
              </div>
              <div className="overflow-hidden">
                <p className="text-neon-green text-xs font-mono truncate">{user?.username}</p>
                <p className="text-gray-600 text-xs truncate">{user?.email}</p>
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded text-sm text-gray-500 hover:text-red-400 hover:bg-red-900/10 transition-all font-mono"
          >
            <MdLogout className="text-xl flex-shrink-0" />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>

        {/* Toggle sidebar button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-6 w-6 h-6 bg-cyber-dark border border-cyber-border rounded-full flex items-center justify-center text-gray-500 hover:text-neon-green hover:border-neon-green/50 transition-all text-xs"
        >
          {sidebarOpen ? <MdClose /> : <MdMenu />}
        </button>
      </aside>

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1 overflow-auto">
        {/* Top bar */}
        <header className="border-b border-cyber-border bg-cyber-dark px-6 py-3 flex items-center justify-between">
          <div className="text-xs text-gray-600 font-mono">
            <span className="text-neon-green">●</span> SYSTEM ONLINE
            <span className="mx-3">|</span>
            {new Date().toLocaleString()}
          </div>
          <div className="text-xs text-gray-600 font-mono">
            USER: <span className="text-neon-green">{user?.username?.toUpperCase()}</span>
          </div>
        </header>

        {/* Page content */}
        <div className="p-6 page-enter">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
