/**
 * App.jsx
 * Root component - sets up React Router and authentication
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'

// Pages
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import Dashboard from './pages/Dashboard'
import ScannerPage from './pages/ScannerPage'
import ScanLivePage from './pages/ScanLivePage'
import ReportPage from './pages/ReportPage'
import HistoryPage from './pages/HistoryPage'

// Layout wrapper that includes the sidebar
import Layout from './components/Layout'

// Protected route component - redirects to login if not authenticated
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth()
  
  if (loading) {
    return (
      <div className="min-h-screen bg-cyber-black flex items-center justify-center">
        <div className="text-center">
          <div className="spinner mx-auto mb-4"></div>
          <p className="text-neon-green font-mono text-sm">INITIALIZING WEBSCAN X...</p>
        </div>
      </div>
    )
  }
  
  return isAuthenticated ? children : <Navigate to="/login" replace />
}

// Public route - redirects to dashboard if already logged in
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth()
  
  if (loading) return null
  
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : children
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public routes (login/signup) */}
      <Route path="/login" element={
        <PublicRoute><LoginPage /></PublicRoute>
      } />
      <Route path="/signup" element={
        <PublicRoute><SignupPage /></PublicRoute>
      } />

      {/* Protected routes (wrapped in sidebar Layout) */}
      <Route path="/" element={
        <ProtectedRoute><Layout /></ProtectedRoute>
      }>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="scanner" element={<ScannerPage />} />
        <Route path="scan/live/:scanId" element={<ScanLivePage />} />
        <Route path="scan/report/:scanId" element={<ReportPage />} />
        <Route path="history" element={<HistoryPage />} />
      </Route>

      {/* Catch-all */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  )
}
