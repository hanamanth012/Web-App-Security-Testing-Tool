/**
 * HistoryPage.jsx
 * View all previous scans with search and filter functionality
 */

import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { useAuth } from '../context/AuthContext'
import {
  MdSearch, MdHistory, MdOpenInNew, MdRadar
} from 'react-icons/md'

// Risk level badge
const RiskBadge = ({ level }) => {
  const styles = {
    LOW:      'text-neon-green border-neon-green/40 bg-neon-green/5',
    MEDIUM:   'text-yellow-400 border-yellow-400/40 bg-yellow-400/5',
    HIGH:     'text-orange-400 border-orange-400/40 bg-orange-400/5',
    CRITICAL: 'text-red-400 border-red-400/40 bg-red-400/5',
    UNKNOWN:  'text-gray-500 border-gray-500/40 bg-gray-500/5',
  }
  return (
    <span className={`text-xs font-mono px-2 py-0.5 border rounded ${styles[level] || styles.UNKNOWN}`}>
      {level}
    </span>
  )
}

// Score bar visualization
const ScoreBar = ({ score }) => {
  const color = score >= 80 ? '#00ff41' : score >= 60 ? '#ffcc00' : score >= 40 ? '#ff6b00' : '#ff0040'
  return (
    <div className="flex items-center gap-2">
      <div className="progress-bar h-1.5 w-16">
        <div
          className="progress-fill"
          style={{ width: `${score}%`, background: color, boxShadow: `0 0 6px ${color}` }}
        />
      </div>
      <span className="text-xs font-mono" style={{ color }}>{score}</span>
    </div>
  )
}

export default function HistoryPage() {
  const { API_URL } = useAuth()
  const navigate = useNavigate()

  const [scans, setScans] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterLevel, setFilterLevel] = useState('ALL')

  useEffect(() => {
    fetchHistory()
  }, [])

  const fetchHistory = async () => {
    try {
      const res = await axios.get(`${API_URL}/scan/history`)
      setScans(res.data.scans)
    } catch (err) {
      console.error('Failed to fetch history:', err)
    } finally {
      setLoading(false)
    }
  }

  // Apply search and filter
  const filteredScans = scans.filter(scan => {
    const matchesSearch = scan.url.toLowerCase().includes(search.toLowerCase())
    const matchesFilter = filterLevel === 'ALL' || scan.risk_level === filterLevel
    return matchesSearch && matchesFilter
  })

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="font-display text-xl font-bold text-neon-green tracking-wider neon-text">
          SCAN HISTORY
        </h1>
        <p className="text-gray-600 text-xs font-mono mt-1">
          All previous security scans — {scans.length} total
        </p>
      </div>

      {/* Controls row */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search input */}
        <div className="relative flex-1">
          <MdSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by URL..."
            className="cyber-input w-full pl-9 pr-4 py-2.5 rounded text-sm"
          />
        </div>

        {/* Risk level filter */}
        <div className="flex gap-1">
          {['ALL', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map(level => (
            <button
              key={level}
              onClick={() => setFilterLevel(level)}
              className={`text-xs font-mono px-3 py-2 rounded border transition-all
                ${filterLevel === level
                  ? 'border-neon-green text-neon-green bg-neon-green/10'
                  : 'border-cyber-border text-gray-600 hover:border-neon-green/30'
                }`}
            >
              {level}
            </button>
          ))}
        </div>

        {/* New scan button */}
        <button
          onClick={() => navigate('/scanner')}
          className="cyber-btn cyber-btn-solid px-4 py-2 rounded text-sm flex items-center gap-2"
        >
          <MdRadar /> NEW SCAN
        </button>
      </div>

      {/* Scans table */}
      <div className="cyber-card overflow-hidden">
        {/* Table header */}
        <div className="grid grid-cols-12 gap-4 px-4 py-3 border-b border-cyber-border bg-cyber-dark/50 text-xs font-mono text-gray-600 tracking-wider">
          <div className="col-span-4">TARGET URL</div>
          <div className="col-span-2">RISK LEVEL</div>
          <div className="col-span-2">SCORE</div>
          <div className="col-span-2">FINDINGS</div>
          <div className="col-span-1">DATE</div>
          <div className="col-span-1 text-right">ACTION</div>
        </div>

        {/* Table body */}
        {loading ? (
          <div className="space-y-0">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-14 border-b border-cyber-border animate-pulse bg-cyber-gray/10" />
            ))}
          </div>
        ) : filteredScans.length > 0 ? (
          filteredScans.map((scan) => (
            <div
              key={scan.id}
              className="grid grid-cols-12 gap-4 px-4 py-3 border-b border-cyber-border hover:bg-neon-green/3 transition-all items-center group"
            >
              {/* URL */}
              <div className="col-span-4 min-w-0">
                <p className="text-neon-green/80 text-xs font-mono truncate">{scan.url}</p>
                <p className="text-gray-700 text-xs font-mono">{scan.status.toUpperCase()}</p>
              </div>

              {/* Risk level */}
              <div className="col-span-2">
                <RiskBadge level={scan.risk_level} />
              </div>

              {/* Score bar */}
              <div className="col-span-2">
                <ScoreBar score={scan.risk_score || 0} />
              </div>

              {/* Findings count */}
              <div className="col-span-2">
                <span className="text-neon-green/70 text-xs font-mono">
                  {scan.total_findings} found
                </span>
              </div>

              {/* Date */}
              <div className="col-span-1">
                <span className="text-gray-600 text-xs font-mono">
                  {new Date(scan.started_at).toLocaleDateString()}
                </span>
              </div>

              {/* View button */}
              <div className="col-span-1 text-right">
                <button
                  onClick={() => navigate(`/scan/report/${scan.id}`)}
                  className="text-gray-600 hover:text-neon-green transition-colors opacity-0 group-hover:opacity-100"
                  title="View Report"
                >
                  <MdOpenInNew className="text-lg" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="py-16 text-center">
            <MdHistory className="text-4xl text-gray-700 mx-auto mb-3" />
            <p className="text-gray-600 text-sm font-mono">
              {search || filterLevel !== 'ALL'
                ? 'No scans match your search/filter'
                : 'No scans yet. Run your first scan!'}
            </p>
            {!search && filterLevel === 'ALL' && (
              <button
                onClick={() => navigate('/scanner')}
                className="cyber-btn mt-4 px-6 py-2 rounded text-sm inline-flex items-center gap-2"
              >
                <MdRadar /> LAUNCH SCANNER
              </button>
            )}
          </div>
        )}
      </div>

      {/* Summary row */}
      {filteredScans.length > 0 && (
        <div className="text-xs font-mono text-gray-600 text-right">
          Showing {filteredScans.length} of {scans.length} scans
        </div>
      )}
    </div>
  )
}
