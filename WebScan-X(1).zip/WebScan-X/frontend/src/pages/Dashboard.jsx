/**
 * Dashboard.jsx
 * Main dashboard with stats overview, recent scans, and vulnerability chart
 */

import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { useAuth } from '../context/AuthContext'
import {
  MdSecurity, MdBugReport, MdSpeed, MdWarning,
  MdRadar, MdHistory
} from 'react-icons/md'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell
} from 'recharts'

// Reusable stat card component
const StatCard = ({ icon: Icon, label, value, color, subtitle }) => (
  <div className={`cyber-card p-5 border-l-2 transition-all hover:scale-[1.02]`}
    style={{ borderLeftColor: color }}>
    <div className="flex items-start justify-between">
      <div>
        <p className="text-gray-600 text-xs font-mono tracking-wider mb-1">{label}</p>
        <p className="text-2xl font-bold font-mono" style={{ color }}>{value}</p>
        {subtitle && <p className="text-gray-700 text-xs mt-1 font-mono">{subtitle}</p>}
      </div>
      <Icon className="text-3xl opacity-30" style={{ color }} />
    </div>
  </div>
)

// Risk level badge
const RiskBadge = ({ level }) => {
  const colors = {
    LOW: 'text-neon-green border-neon-green/40 bg-neon-green/5',
    MEDIUM: 'text-yellow-400 border-yellow-400/40 bg-yellow-400/5',
    HIGH: 'text-orange-400 border-orange-400/40 bg-orange-400/5',
    CRITICAL: 'text-red-400 border-red-400/40 bg-red-400/5',
    UNKNOWN: 'text-gray-500 border-gray-500/40 bg-gray-500/5',
  }
  return (
    <span className={`text-xs font-mono px-2 py-0.5 border rounded ${colors[level] || colors.UNKNOWN}`}>
      {level}
    </span>
  )
}

export default function Dashboard() {
  const { API_URL, user } = useAuth()
  const navigate = useNavigate()
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      const res = await axios.get(`${API_URL}/dashboard/stats`)
      setStats(res.data)
    } catch (err) {
      console.error('Failed to fetch stats:', err)
    } finally {
      setLoading(false)
    }
  }

  // Chart data for vulnerability severity breakdown
  const chartData = stats ? [
    { name: 'CRITICAL', value: 2, color: '#ff0040' },
    { name: 'HIGH', value: 5, color: '#ff6b00' },
    { name: 'MEDIUM', value: 8, color: '#ffcc00' },
    { name: 'LOW', value: 3, color: '#00bfff' },
    { name: 'INFO', value: 4, color: '#555555' },
  ] : []

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload?.length) {
      return (
        <div className="bg-cyber-dark border border-cyber-border p-2 text-xs font-mono">
          <p style={{ color: payload[0].fill }}>{payload[0].payload.name}: {payload[0].value}</p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="space-y-6">
      {/* Page title */}
      <div>
        <h1 className="font-display text-xl font-bold text-neon-green tracking-wider neon-text">
          SECURITY DASHBOARD
        </h1>
        <p className="text-gray-600 text-xs font-mono mt-1">
          Welcome back, <span className="text-neon-green">{user?.username}</span> // System status: OPERATIONAL
        </p>
      </div>

      {/* Quick scan CTA */}
      <div className="cyber-card p-4 border border-neon-green/20 bg-neon-green/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <MdRadar className="text-neon-green text-2xl animate-pulse" />
          <div>
            <p className="text-neon-green text-sm font-mono font-bold">READY TO SCAN</p>
            <p className="text-gray-600 text-xs font-mono">Analyze target website for vulnerabilities</p>
          </div>
        </div>
        <button
          onClick={() => navigate('/scanner')}
          className="cyber-btn px-6 py-2 rounded text-sm tracking-widest"
        >
          LAUNCH SCAN →
        </button>
      </div>

      {/* Stats grid */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="cyber-card p-5 h-24 animate-pulse bg-cyber-gray/30" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={MdSecurity}
            label="TOTAL SCANS"
            value={stats?.total_scans ?? 0}
            color="#00ff41"
            subtitle={`${stats?.completed_scans ?? 0} completed`}
          />
          <StatCard
            icon={MdBugReport}
            label="VULNERABILITIES"
            value={stats?.total_vulnerabilities ?? 0}
            color="#ff6b00"
            subtitle="across all scans"
          />
          <StatCard
            icon={MdWarning}
            label="CRITICAL ISSUES"
            value={stats?.critical_vulnerabilities ?? 0}
            color="#ff0040"
            subtitle="require immediate action"
          />
          <StatCard
            icon={MdSpeed}
            label="AVG RISK SCORE"
            value={stats?.average_risk_score ?? 'N/A'}
            color="#00bfff"
            subtitle="out of 100"
          />
        </div>
      )}

      {/* Charts + Recent Scans */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Vulnerability Chart */}
        <div className="cyber-card p-5">
          <h2 className="text-neon-green font-mono text-xs tracking-widest mb-4">
            &gt; VULNERABILITY DISTRIBUTION
          </h2>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData} barSize={30}>
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#555', fontSize: 10, fontFamily: 'JetBrains Mono' }}
                  axisLine={{ stroke: '#1f1f1f' }}
                />
                <YAxis
                  tick={{ fill: '#555', fontSize: 10, fontFamily: 'JetBrains Mono' }}
                  axisLine={{ stroke: '#1f1f1f' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" radius={[2, 2, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-700 text-xs font-mono">
              No scan data yet. Run your first scan.
            </div>
          )}
        </div>

        {/* Recent Scans */}
        <div className="cyber-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-neon-green font-mono text-xs tracking-widest">
              &gt; RECENT SCANS
            </h2>
            <button
              onClick={() => navigate('/history')}
              className="text-gray-600 hover:text-neon-green text-xs font-mono transition-colors flex items-center gap-1"
            >
              <MdHistory /> VIEW ALL
            </button>
          </div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-12 bg-cyber-gray/30 rounded animate-pulse" />
              ))}
            </div>
          ) : stats?.recent_scans?.length > 0 ? (
            <div className="space-y-2">
              {stats.recent_scans.map((scan) => (
                <div
                  key={scan.id}
                  className="flex items-center justify-between p-3 border border-cyber-border rounded hover:border-neon-green/20 transition-all cursor-pointer"
                  onClick={() => navigate(`/scan/report/${scan.id}`)}
                >
                  <div className="min-w-0">
                    <p className="text-neon-green text-xs font-mono truncate">{scan.url}</p>
                    <p className="text-gray-700 text-xs font-mono">
                      {new Date(scan.started_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="ml-3 flex-shrink-0">
                    <RiskBadge level={scan.risk_level} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-48 flex flex-col items-center justify-center text-gray-700 text-xs font-mono gap-2">
              <MdSecurity className="text-3xl" />
              <span>No scans yet</span>
              <button
                onClick={() => navigate('/scanner')}
                className="text-neon-green hover:underline mt-1"
              >
                Start your first scan →
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Threat level indicators */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'SQL INJECTION', status: 'MONITORED', color: '#00ff41' },
          { label: 'XSS ATTACKS', status: 'MONITORED', color: '#00ff41' },
          { label: 'SSL/TLS', status: 'CHECKING', color: '#ffcc00' },
          { label: 'OPEN PORTS', status: 'SCANNING', color: '#ff6b00' },
        ].map((item) => (
          <div key={item.label} className="cyber-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div
                className="w-2 h-2 rounded-full animate-pulse"
                style={{ backgroundColor: item.color, boxShadow: `0 0 6px ${item.color}` }}
              />
              <span className="text-xs font-mono text-gray-600">{item.status}</span>
            </div>
            <p className="text-xs font-mono font-bold" style={{ color: item.color }}>
              {item.label}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
