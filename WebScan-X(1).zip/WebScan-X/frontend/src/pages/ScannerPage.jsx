/**
 * ScannerPage.jsx
 * URL input and scan configuration page
 */

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { useAuth } from '../context/AuthContext'
import {
  MdSearch, MdSecurity, MdWarning, MdInfo
} from 'react-icons/md'
import { RiRadarLine } from 'react-icons/ri'

// Scan feature descriptions shown to user
const SCAN_FEATURES = [
  { icon: '🔐', label: 'Security Headers', desc: 'HSTS, CSP, X-Frame-Options analysis' },
  { icon: '💉', label: 'SQL Injection', desc: 'Parameter-based injection detection' },
  { icon: '🚨', label: 'XSS Detection', desc: 'Cross-site scripting vulnerability scan' },
  { icon: '🔒', label: 'SSL Certificate', desc: 'Certificate validity and configuration' },
  { icon: '🍪', label: 'Cookie Security', desc: 'HttpOnly, Secure, SameSite flags' },
  { icon: '🌐', label: 'Port Detection', desc: 'Common open port simulation' },
  { icon: '🧰', label: 'Tech Detection', desc: 'Framework and CMS identification' },
]

export default function ScannerPage() {
  const { API_URL } = useAuth()
  const navigate = useNavigate()

  const [url, setUrl] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  // Validate URL format
  const isValidUrl = (str) => {
    try {
      const u = str.startsWith('http') ? str : `https://${str}`
      new URL(u)
      return true
    } catch {
      return false
    }
  }

  const handleScan = async () => {
    if (!url.trim()) {
      setError('Please enter a target URL')
      return
    }
    if (!isValidUrl(url)) {
      setError('Please enter a valid URL (e.g. https://example.com)')
      return
    }

    setError('')
    setLoading(true)

    try {
      const res = await axios.post(`${API_URL}/scan/start`, { url })
      // Navigate to live scan screen with the scan ID
      navigate(`/scan/live/${res.data.scan_id}`, {
        state: { url: res.data.url }
      })
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to start scan. Check backend connection.')
      setLoading(false)
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') handleScan()
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      {/* Title */}
      <div>
        <h1 className="font-display text-xl font-bold text-neon-green tracking-wider neon-text">
          URL SECURITY SCANNER
        </h1>
        <p className="text-gray-600 text-xs font-mono mt-1">
          Analyze target web application for security vulnerabilities
        </p>
      </div>

      {/* Warning banner */}
      <div className="p-3 border border-yellow-500/30 bg-yellow-500/5 rounded flex items-start gap-3">
        <MdWarning className="text-yellow-400 text-lg flex-shrink-0 mt-0.5" />
        <p className="text-yellow-400/70 text-xs font-mono">
          <strong>ETHICAL USE ONLY:</strong> Only scan websites you own or have explicit permission to test.
          Unauthorized scanning may violate laws.
        </p>
      </div>

      {/* URL Input */}
      <div className="cyber-card p-6">
        <div className="mb-4">
          <h2 className="text-neon-green font-mono text-sm tracking-widest">
            &gt; ENTER TARGET URL
          </h2>
          <div className="h-px bg-neon-green/20 mt-2"></div>
        </div>

        <div className="flex gap-3">
          <div className="relative flex-1">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600 font-mono text-sm">
              https://
            </span>
            <input
              type="text"
              value={url}
              onChange={(e) => { setUrl(e.target.value); setError('') }}
              onKeyPress={handleKeyPress}
              placeholder="target-website.com"
              className="cyber-input w-full pl-16 pr-4 py-3 rounded text-sm"
              disabled={loading}
            />
          </div>
          <button
            onClick={handleScan}
            disabled={loading}
            className="cyber-btn cyber-btn-solid px-6 py-3 rounded text-sm tracking-wider flex items-center gap-2 flex-shrink-0"
          >
            {loading ? (
              <>
                <div className="spinner" style={{ borderTopColor: '#0a0a0a' }}></div>
                <span>INIT...</span>
              </>
            ) : (
              <>
                <RiRadarLine />
                <span>SCAN</span>
              </>
            )}
          </button>
        </div>

        {error && (
          <p className="mt-2 text-red-400 text-xs font-mono flex items-center gap-1">
            <MdWarning /> {error}
          </p>
        )}

        {/* Quick target examples */}
        <div className="mt-4 pt-4 border-t border-cyber-border">
          <p className="text-gray-700 text-xs font-mono mb-2">EXAMPLE TARGETS:</p>
          <div className="flex flex-wrap gap-2">
            {['https://example.com', 'https://httpbin.org', 'https://testphp.vulnweb.com'].map((ex) => (
              <button
                key={ex}
                onClick={() => setUrl(ex)}
                className="text-xs font-mono text-gray-600 hover:text-neon-green border border-cyber-border hover:border-neon-green/30 px-2 py-1 rounded transition-all"
              >
                {ex}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Scan features list */}
      <div className="cyber-card p-6">
        <div className="mb-4">
          <h2 className="text-neon-green font-mono text-sm tracking-widest flex items-center gap-2">
            <MdInfo />
            &gt; SCAN MODULES
          </h2>
          <div className="h-px bg-neon-green/20 mt-2"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {SCAN_FEATURES.map((feat) => (
            <div
              key={feat.label}
              className="flex items-start gap-3 p-3 border border-cyber-border rounded hover:border-neon-green/20 transition-all"
            >
              <span className="text-xl">{feat.icon}</span>
              <div>
                <p className="text-neon-green text-xs font-mono font-bold">{feat.label}</p>
                <p className="text-gray-600 text-xs font-mono mt-0.5">{feat.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scan info */}
      <div className="p-4 border border-cyber-border rounded">
        <div className="flex items-center gap-2 text-gray-600 text-xs font-mono">
          <MdSecurity className="text-neon-green" />
          <span>Average scan time: <strong className="text-neon-green">10-30 seconds</strong> depending on target</span>
        </div>
      </div>
    </div>
  )
}
