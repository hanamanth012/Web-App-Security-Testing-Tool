/**
 * LoginPage.jsx
 * Cyberpunk-styled authentication page
 */

import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { MdShield, MdEmail, MdLock, MdError } from 'react-icons/md'
import { RiTerminalLine } from 'react-icons/ri'

export default function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('') // Clear error on input change
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      await login(form.email, form.password)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.error || 'Authentication failed. Check credentials.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-cyber-black grid-bg flex items-center justify-center p-4">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 text-neon-green/5 font-mono text-xs leading-4 select-none">
          {Array.from({ length: 20 }, (_, i) => (
            <div key={i}>{Math.random().toString(36).substring(2, 15)}</div>
          ))}
        </div>
        <div className="absolute top-20 right-10 text-neon-green/5 font-mono text-xs leading-4 select-none">
          {Array.from({ length: 20 }, (_, i) => (
            <div key={i}>{Math.random().toString(36).substring(2, 15)}</div>
          ))}
        </div>
      </div>

      {/* Login Card */}
      <div className="w-full max-w-md z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <MdShield className="text-neon-green text-4xl" style={{ filter: 'drop-shadow(0 0 8px #00ff41)' }} />
            <h1 className="font-display text-3xl font-bold text-neon-green neon-text-lg tracking-widest">
              WEBSCAN<span className="text-white">X</span>
            </h1>
          </div>
          <p className="text-gray-600 text-sm font-mono">Web Application Security Testing Suite</p>
          <div className="mt-2 flex items-center justify-center gap-2 text-xs text-gray-700">
            <RiTerminalLine />
            <span>v2.4.1 // AUTHORIZED ACCESS ONLY</span>
          </div>
        </div>

        {/* Form container */}
        <div className="cyber-card p-8 scan-overlay">
          <div className="mb-6">
            <h2 className="text-neon-green font-mono text-sm tracking-widest">
              &gt; AUTHENTICATE USER
            </h2>
            <div className="h-px bg-neon-green/20 mt-2"></div>
          </div>

          {/* Error message */}
          {error && (
            <div className="mb-4 p-3 border border-red-500/50 bg-red-900/10 rounded flex items-center gap-2">
              <MdError className="text-red-400 flex-shrink-0" />
              <p className="text-red-400 text-xs font-mono">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email field */}
            <div>
              <label className="block text-xs text-gray-600 font-mono mb-1 tracking-wider">
                EMAIL ADDRESS
              </label>
              <div className="relative">
                <MdEmail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="operator@domain.com"
                  required
                  className="cyber-input w-full pl-9 pr-4 py-3 rounded text-sm"
                />
              </div>
            </div>

            {/* Password field */}
            <div>
              <label className="block text-xs text-gray-600 font-mono mb-1 tracking-wider">
                PASSWORD
              </label>
              <div className="relative">
                <MdLock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="password"
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                  className="cyber-input w-full pl-9 pr-4 py-3 rounded text-sm"
                />
              </div>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={loading}
              className="cyber-btn cyber-btn-solid w-full py-3 rounded text-sm tracking-widest mt-2 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="spinner" style={{ borderTopColor: '#0a0a0a' }}></div>
                  <span>AUTHENTICATING...</span>
                </>
              ) : (
                '[ INITIATE LOGIN ]'
              )}
            </button>
          </form>

          {/* Signup link */}
          <div className="mt-6 pt-4 border-t border-cyber-border text-center">
            <p className="text-gray-600 text-xs font-mono">
              No account?{' '}
              <Link to="/signup" className="text-neon-green hover:underline">
                REGISTER NEW OPERATOR
              </Link>
            </p>
          </div>
        </div>

        {/* Demo credentials hint */}
        <div className="mt-4 p-3 border border-neon-green/10 rounded text-xs font-mono text-gray-700 text-center">
          Create an account to start scanning
        </div>
      </div>
    </div>
  )
}
