/**
 * SignupPage.jsx
 * New operator registration page
 */

import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { MdShield, MdEmail, MdLock, MdPerson, MdError } from 'react-icons/md'

export default function SignupPage() {
  const { signup } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({ username: '', email: '', password: '', confirm: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    // Client-side validation
    if (form.password !== form.confirm) {
      setError('Passwords do not match')
      return
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }

    setLoading(true)
    try {
      await signup(form.username, form.email, form.password)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed. Try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-cyber-black grid-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <MdShield className="text-neon-green text-4xl" style={{ filter: 'drop-shadow(0 0 8px #00ff41)' }} />
            <h1 className="font-display text-3xl font-bold text-neon-green neon-text-lg tracking-widest">
              WEBSCAN<span className="text-white">X</span>
            </h1>
          </div>
          <p className="text-gray-600 text-sm font-mono">Register New Security Operator</p>
        </div>

        <div className="cyber-card p-8 scan-overlay">
          <div className="mb-6">
            <h2 className="text-neon-green font-mono text-sm tracking-widest">
              &gt; CREATE ACCOUNT
            </h2>
            <div className="h-px bg-neon-green/20 mt-2"></div>
          </div>

          {error && (
            <div className="mb-4 p-3 border border-red-500/50 bg-red-900/10 rounded flex items-center gap-2">
              <MdError className="text-red-400 flex-shrink-0" />
              <p className="text-red-400 text-xs font-mono">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username */}
            <div>
              <label className="block text-xs text-gray-600 font-mono mb-1 tracking-wider">OPERATOR NAME</label>
              <div className="relative">
                <MdPerson className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="text"
                  name="username"
                  value={form.username}
                  onChange={handleChange}
                  placeholder="operator_name"
                  required
                  className="cyber-input w-full pl-9 pr-4 py-3 rounded text-sm"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs text-gray-600 font-mono mb-1 tracking-wider">EMAIL ADDRESS</label>
              <div className="relative">
                <MdEmail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="operator@domain.com"
                  required
                  className="cyber-input w-full pl-9 pr-4 py-3 rounded text-sm"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs text-gray-600 font-mono mb-1 tracking-wider">PASSWORD</label>
              <div className="relative">
                <MdLock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="password"
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  placeholder="min. 6 characters"
                  required
                  className="cyber-input w-full pl-9 pr-4 py-3 rounded text-sm"
                />
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-xs text-gray-600 font-mono mb-1 tracking-wider">CONFIRM PASSWORD</label>
              <div className="relative">
                <MdLock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="password"
                  name="confirm"
                  value={form.confirm}
                  onChange={handleChange}
                  placeholder="repeat password"
                  required
                  className="cyber-input w-full pl-9 pr-4 py-3 rounded text-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="cyber-btn cyber-btn-solid w-full py-3 rounded text-sm tracking-widest mt-2 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="spinner" style={{ borderTopColor: '#0a0a0a' }}></div>
                  <span>REGISTERING...</span>
                </>
              ) : (
                '[ REGISTER OPERATOR ]'
              )}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-cyber-border text-center">
            <p className="text-gray-600 text-xs font-mono">
              Already registered?{' '}
              <Link to="/login" className="text-neon-green hover:underline">
                LOGIN HERE
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
