/**
 * ScanLivePage.jsx
 * Animated live scan screen with terminal logs and progress bar
 */

import { useState, useEffect, useRef } from 'react'
import { useNavigate, useParams, useLocation } from 'react-router-dom'
import axios from 'axios'
import { useAuth } from '../context/AuthContext'
import { MdCheckCircle, MdRadar } from 'react-icons/md'

// Simulated log messages that appear during scanning
const SCAN_LOG_MESSAGES = [
  { delay: 0,    msg: '[ INIT ] Initializing WebScan X engine...' },
  { delay: 300,  msg: '[ SYS  ] Loading security modules...' },
  { delay: 600,  msg: '[ NET  ] Establishing connection to target...' },
  { delay: 900,  msg: '[ DNS  ] Resolving hostname...' },
  { delay: 1200, msg: '[ HTTP ] Sending HTTP GET request...' },
  { delay: 1500, msg: '[ HDR  ] Analyzing response headers...' },
  { delay: 1800, msg: '[ SSL  ] Checking TLS/SSL certificate...' },
  { delay: 2100, msg: '[ SSL  ] Validating certificate chain...' },
  { delay: 2400, msg: '[ HDR  ] Checking Strict-Transport-Security...' },
  { delay: 2700, msg: '[ HDR  ] Checking Content-Security-Policy...' },
  { delay: 3000, msg: '[ HDR  ] Checking X-Frame-Options...' },
  { delay: 3300, msg: '[ HDR  ] Checking X-XSS-Protection...' },
  { delay: 3600, msg: '[ XSS  ] Loading XSS detection module...' },
  { delay: 3900, msg: '[ XSS  ] Crawling target for input forms...' },
  { delay: 4200, msg: '[ XSS  ] Testing reflected XSS vectors...' },
  { delay: 4500, msg: '[ XSS  ] Analyzing DOM for sinks...' },
  { delay: 4800, msg: '[ SQLI ] Loading SQL injection module...' },
  { delay: 5100, msg: '[ SQLI ] Detecting URL parameters...' },
  { delay: 5400, msg: '[ SQLI ] Testing error-based injection...' },
  { delay: 5700, msg: '[ SQLI ] Testing boolean-based blind injection...' },
  { delay: 6000, msg: '[ COOK ] Analyzing session cookies...' },
  { delay: 6300, msg: '[ COOK ] Checking HttpOnly flag...' },
  { delay: 6600, msg: '[ COOK ] Checking Secure flag...' },
  { delay: 6900, msg: '[ PORT ] Starting port simulation scan...' },
  { delay: 7200, msg: '[ PORT ] Probing common ports: 80, 443, 22...' },
  { delay: 7500, msg: '[ PORT ] Probing extended range...' },
  { delay: 7800, msg: '[ TECH ] Detecting web technologies...' },
  { delay: 8100, msg: '[ TECH ] Fingerprinting CMS/framework...' },
  { delay: 8400, msg: '[ RPT  ] Aggregating scan results...' },
  { delay: 8700, msg: '[ RPT  ] Calculating risk score...' },
  { delay: 9000, msg: '[ RPT  ] Generating vulnerability report...' },
  { delay: 9300, msg: '[ DONE ] Scan complete. Preparing results...' },
]

// Scan phases for the progress section
const SCAN_PHASES = [
  'DNS Resolution',
  'SSL/TLS Check',
  'Header Analysis',
  'XSS Detection',
  'SQL Injection',
  'Cookie Audit',
  'Port Scan',
  'Tech Detection',
  'Risk Scoring',
]

export default function ScanLivePage() {
  const { scanId } = useParams()
  const { state } = useLocation()
  const { API_URL } = useAuth()
  const navigate = useNavigate()

  const [logs, setLogs] = useState([])
  const [progress, setProgress] = useState(0)
  const [currentPhase, setCurrentPhase] = useState(0)
  const [scanComplete, setScanComplete] = useState(false)
  const [error, setError] = useState('')

  const terminalRef = useRef(null)
  const targetUrl = state?.url || 'Unknown Target'

  useEffect(() => {
    // Add log messages with delays (simulated terminal output)
    SCAN_LOG_MESSAGES.forEach(({ delay, msg }) => {
      setTimeout(() => {
        setLogs(prev => [...prev, { text: msg, time: new Date().toLocaleTimeString() }])
      }, delay)
    })

    // Animate progress bar
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 95) {
          clearInterval(progressInterval)
          return 95
        }
        return prev + 1
      })
    }, 100)

    // Advance scan phases
    const phaseInterval = setInterval(() => {
      setCurrentPhase(prev => {
        if (prev >= SCAN_PHASES.length - 1) {
          clearInterval(phaseInterval)
          return prev
        }
        return prev + 1
      })
    }, 1100)

    // Actually fetch scan results after enough time
    const fetchTimer = setTimeout(async () => {
      try {
        await axios.get(`${API_URL}/scan/results/${scanId}`)
        setProgress(100)
        setScanComplete(true)
        setLogs(prev => [...prev, { text: '[ ✓   ] All checks complete. Report ready!', time: new Date().toLocaleTimeString() }])

        // Auto-navigate to report after a moment
        setTimeout(() => {
          navigate(`/scan/report/${scanId}`)
        }, 2000)
      } catch (err) {
        setError('Scan failed: ' + (err.response?.data?.error || 'Connection error'))
      }
    }, 9500)

    return () => {
      clearInterval(progressInterval)
      clearInterval(phaseInterval)
      clearTimeout(fetchTimer)
    }
  }, [scanId])

  // Auto-scroll terminal to bottom
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [logs])

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      {/* Title */}
      <div className="flex items-center gap-3">
        <MdRadar className="text-neon-green text-2xl animate-spin" style={{ animationDuration: '3s' }} />
        <div>
          <h1 className="font-display text-xl font-bold text-neon-green tracking-wider neon-text">
            LIVE SCAN
          </h1>
          <p className="text-gray-600 text-xs font-mono">
            Target: <span className="text-neon-green">{targetUrl}</span>
          </p>
        </div>
      </div>

      {/* Progress card */}
      <div className="cyber-card p-5">
        {/* Overall progress bar */}
        <div className="mb-4">
          <div className="flex justify-between text-xs font-mono mb-2">
            <span className="text-gray-500">SCAN PROGRESS</span>
            <span className="text-neon-green">{progress}%</span>
          </div>
          <div className="progress-bar h-2">
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>

        {/* Phase indicators */}
        <div className="grid grid-cols-3 gap-2">
          {SCAN_PHASES.map((phase, idx) => (
            <div
              key={phase}
              className={`flex items-center gap-1.5 p-2 rounded border text-xs font-mono transition-all duration-500
                ${idx < currentPhase
                  ? 'border-neon-green/30 text-neon-green bg-neon-green/5'
                  : idx === currentPhase
                    ? 'border-neon-green/60 text-neon-green animate-pulse'
                    : 'border-cyber-border text-gray-700'
                }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                idx < currentPhase ? 'bg-neon-green' :
                idx === currentPhase ? 'bg-neon-green animate-pulse' : 'bg-gray-700'
              }`} />
              {phase}
            </div>
          ))}
        </div>
      </div>

      {/* Terminal output */}
      <div className="cyber-card">
        {/* Terminal header bar */}
        <div className="flex items-center gap-2 p-3 border-b border-cyber-border bg-cyber-dark/50">
          <div className="w-3 h-3 rounded-full bg-red-500/60" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
          <div className="w-3 h-3 rounded-full bg-neon-green/60" />
          <span className="ml-2 text-xs text-gray-600 font-mono">webscan-x terminal</span>
        </div>

        {/* Terminal content */}
        <div
          ref={terminalRef}
          className="p-4 h-72 overflow-y-auto font-mono text-xs space-y-1 bg-cyber-dark/30"
        >
          <p className="text-gray-600 mb-2">
            WebScan X v2.4.1 — Security Analysis Engine<br />
            Scan ID: <span className="text-neon-green">{scanId}</span>
          </p>
          <p className="text-gray-600 mb-3">━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</p>

          {logs.map((log, idx) => (
            <div key={idx} className="flex gap-3 animate-fade-in">
              <span className="text-gray-700 flex-shrink-0">{log.time}</span>
              <span className={
                log.text.includes('✓') ? 'text-neon-green' :
                log.text.includes('INIT') ? 'text-yellow-400' :
                log.text.includes('SSL') ? 'text-blue-400' :
                log.text.includes('XSS') || log.text.includes('SQLI') ? 'text-orange-400' :
                'text-neon-green/70'
              }>
                {log.text}
              </span>
            </div>
          ))}

          {/* Blinking cursor at end */}
          {!scanComplete && (
            <span className="text-neon-green cursor" />
          )}
        </div>
      </div>

      {/* Completion message */}
      {scanComplete && (
        <div className="cyber-card p-4 border border-neon-green/40 bg-neon-green/5 flex items-center gap-3 animate-fade-in">
          <MdCheckCircle className="text-neon-green text-2xl" />
          <div>
            <p className="text-neon-green text-sm font-mono font-bold">SCAN COMPLETE</p>
            <p className="text-gray-600 text-xs font-mono">Redirecting to vulnerability report...</p>
          </div>
        </div>
      )}

      {/* Error message */}
      {error && (
        <div className="p-4 border border-red-500/40 bg-red-900/10 text-red-400 text-xs font-mono rounded">
          {error}
        </div>
      )}
    </div>
  )
}
