/**
 * AuthContext.jsx
 * Global authentication state management using React Context API
 * Provides login, logout, and user state to all child components
 */

import { createContext, useContext, useState, useEffect } from 'react'
import axios from 'axios'

// API base URL - change this if your backend runs on a different port
const API_URL = 'http://localhost:5000/api'

// Create the context
const AuthContext = createContext(null)

// Custom hook to use auth context easily
export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}

// Auth Provider component - wraps the entire app
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(localStorage.getItem('webscanx_token'))
  const [loading, setLoading] = useState(true)

  // Set default axios authorization header
  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
      // Verify token is still valid
      axios.get(`${API_URL}/auth/me`)
        .then(res => setUser(res.data.user))
        .catch(() => logout())
        .finally(() => setLoading(false))
    } else {
      delete axios.defaults.headers.common['Authorization']
      setLoading(false)
    }
  }, [token])

  // Login function - sends credentials to backend
  const login = async (email, password) => {
    const response = await axios.post(`${API_URL}/auth/login`, { email, password })
    const { token: newToken, user: userData } = response.data
    
    localStorage.setItem('webscanx_token', newToken)
    axios.defaults.headers.common['Authorization'] = `Bearer ${newToken}`
    setToken(newToken)
    setUser(userData)
    return response.data
  }

  // Signup function - creates new account
  const signup = async (username, email, password) => {
    const response = await axios.post(`${API_URL}/auth/signup`, { username, email, password })
    const { token: newToken, user: userData } = response.data
    
    localStorage.setItem('webscanx_token', newToken)
    axios.defaults.headers.common['Authorization'] = `Bearer ${newToken}`
    setToken(newToken)
    setUser(userData)
    return response.data
  }

  // Logout - clear all stored data
  const logout = () => {
    localStorage.removeItem('webscanx_token')
    delete axios.defaults.headers.common['Authorization']
    setToken(null)
    setUser(null)
  }

  // Value provided to all children components
  const value = {
    user,
    token,
    loading,
    login,
    signup,
    logout,
    isAuthenticated: !!token && !!user,
    API_URL
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}
